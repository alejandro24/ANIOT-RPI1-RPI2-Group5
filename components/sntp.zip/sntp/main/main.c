
#include <stdio.h>
#include "sntp.h"

int app_main()
{
    printf("prueba");
    return 0;
}
