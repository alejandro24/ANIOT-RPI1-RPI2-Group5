#ifndef SNTP_H
#define SNTP_H

#include <time.h>
#include <sys/time.h>
#include "esp_system.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_attr.h"
#include "esp_sleep.h"
#include "nvs_flash.h"
#include "protocol_examples_common.h"
#include "esp_netif_sntp.h"
#include "lwip/ip_addr.h"
#include "esp_sntp.h"

#ifdef __cplusplus
extern "C" {
#endif

void sntp_sync_time(struct timeval *tv);
void time_sync_notification_cb(struct timeval *tv);
void sntp_principal(void);
static void print_servers(void);
static void obtain_time(void);

#ifdef __cplusplus
}
#endif

#endif // SNTP_H